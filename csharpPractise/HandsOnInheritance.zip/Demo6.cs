﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOnInheritance
{
    class Class1
    {
        public void M(){}
    }
    class Class2 : Class1 { }
    class Class3 : Class1 { }
    class Demo6
    {
    }
}
