﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOnClassTypes
{
    //partial classes allows to create multiple classes with
    //the same name
    partial class Employee
    {
        public void AddEmployee()
        {

        }
        public string[] GetEmployees()
        {
            return null;
        }
    }
}
